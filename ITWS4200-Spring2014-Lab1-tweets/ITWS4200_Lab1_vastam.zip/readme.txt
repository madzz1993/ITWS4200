This lab was rather difficult for me, as it was hard to generate functions for the tweets to rotate at. I eventually figured it out, and even found some cool effects for 
sliding which was also rather cool to learn. Credits go to: PickleDesign.uk.com for the background of my tweets.

I spent a lot of time actually learning how APIs work and JSON because up until this point, I wasn't familiar with it. I think I have gotten better at it, through this lab however. 