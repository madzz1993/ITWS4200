This particular lab was really interesting for me. Especially because my group's final project is going to be surrounding geolocations. 
I ended up learning a lot, especially with JSON and how to be able to use APIs. I ended up learning a lot of features which could be included in my code, including
the marquees which was very interesting as well.